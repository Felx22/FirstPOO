import java.util.Random;

public class Luta implements lutaInt {
	private LutadorCombate desafiante;
	private LutadorCombate desafiado;
	private int rounds;
	private boolean aprovada;


	@Override
	public void lutar() {
		if (this.aprovada) {
			System.out.println("******* DO MEU LADO DIREITO ESTA ********");
			this.desafiado.status();
			System.out.println("******* DO MEU LADO ESQUERDO ESTA *******");
			this.desafiante.status();
			
			Random aleatorio = new Random();
			int vencedor = aleatorio.nextInt(3);
			System.out.println("E o vencedor eh: ");
			switch(vencedor) {
			case 0:
				System.out.println("Nenhum !! Os lutadores empataram ...");
				desafiante.empatarLuta();
				desafiado.empatarLuta();
				break;
			case 1:
				System.out.println("O lutador "+ desafiante.getNome());
				desafiante.ganharLuta();
				desafiado.perderLuta();
				break;
			case 2:
				System.out.println("O lutador "+ desafiado.getNome());
				desafiado.ganharLuta();
				desafiante.perderLuta();
				break;
			}
		}
	}


	public Lutador getDesafiante() {
		return desafiante;
	}


	public void setDesafiante(LutadorCombate desafiante) {
		this.desafiante = desafiante;
	}


	public Lutador getDesafiado() {
		return desafiado;
	}


	public void setDesafiado(LutadorCombate desafiado) {
		this.desafiado = desafiado;
	}


	public int getRounds() {
		return rounds;
	}


	public void setRounds(int rounds) {
		this.rounds = rounds;
	}


	public boolean getAprovada() {
		return aprovada;
	}


	public void setAprovada(boolean aprovada) {
		this.aprovada = aprovada;
	}


	@Override
	public void marcarLuta(LutadorCombate l1, LutadorCombate l2) {
		if(l1.getCategoria().equals(l2.getCategoria()) && l1 != l2){
			this.aprovada = true;
			this.desafiado = l1;
			this.desafiante = l2;
		}else {
			System.out.println("Impossivel fazer o desafio, eles nao possuem a mesma categoria ou sao iguais");
			
			this.aprovada = false;
			this.desafiado = null;
			this.desafiante = null;
		}
		
	}




}