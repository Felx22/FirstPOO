
public interface lutaInt {

	public abstract void lutar();
	void marcarLuta(LutadorCombate l1, LutadorCombate l2);
}
