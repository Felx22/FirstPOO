import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double altura,peso;
		int i,j,vitorias,derrotas,empates,idade;
		String nome,nacionalidade;
		
		
		System.out.println("Quantos lutadores voce deseja cadastrar?\n");
		i = sc.nextInt() + 1;
		int total = i;
		
		
		//int L[] = new int[i];
		LutadorCombate L[] = new LutadorCombate[i];
		
		for (j=1;j<i;j++) {
			
			sc.nextLine();
			
			System.out.println("Digite o nome do "+j+" lutador");
			nome=sc.nextLine();	
			
			System.out.println("Digite a nacionalidade do lutador");
			nacionalidade = sc.nextLine();
			
			System.out.println("Digite a idade do lutador\n");
			idade = sc.nextInt();
			
			System.out.println("Digite a altura do lutador\n");
			altura = sc.nextDouble();
			
			System.out.println("Digite o peso do lutador\n");
			peso = sc.nextDouble();
			
			System.out.println("Digite quantas vitorias o lutador possui\n");
			vitorias = sc.nextInt();
			
			System.out.println("Digite quantas derrotas o lutador possui\n");
			derrotas = sc.nextInt();
			
			System.out.println("Digite quantos empates o lutador possui\n");
			empates = sc.nextInt();
			
			L[j] = new LutadorCombate(nome,nacionalidade,idade,altura,peso,vitorias,derrotas,empates);
			
		}
		Luta lutar = new Luta();
		while (true) {
			System.out.println("1- Marcar Luta/n 2- Consultar Lutador/n 3- Listar lutadores\n4- sair\n");
			i = sc.nextInt();
			switch(i) {
			case 1:
				System.out.println("Digite o primeiro lutador\n");
				i = sc.nextInt();
				System.out.println(L[i].getNome() + " vs");
				System.out.println("Digite o segundo lutador\n");
				j = sc.nextInt();
				System.out.println(L[i].getNome() + " vs "+ L[j].getNome());
				System.out.println("Lutador de numero "+j+" escolhido\n");
				lutar.marcarLuta(L[i],L[j]);
				lutar.lutar();
				break;
			case 2:
				System.out.println("Digite o lutador que deseja consultar\n");
				i = sc.nextInt();
				L[i].apresentar();
				break;
			case 3:
				for (i=1;i<total;i++) {
					System.out.println(i+"- "+ L[i].getNome()+" categoria: "+ L[i].getCategoria());
				}
				break;
			case 4:
				System.out.println("Obrigado por utilizar, espero que tenha se divertido !!");
				sc.close();
				System.exit(0);
				
				break;
			default:
				System.out.println("Opcao Invalida\n");
			}
		}
		
	}
	
}
